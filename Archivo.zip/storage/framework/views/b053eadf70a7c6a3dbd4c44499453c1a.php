<?php if( !empty($label_title) ): ?>
    <li class="op-separator-wrap">
        <div class="op-textcontent">
            <h6><?php echo $label_title; ?></h6>
            <?php if( !empty( $label_desc) ): ?>
                <em><?php echo $label_desc; ?></em>
            <?php endif; ?>
        </div>
    </li>
<?php endif; ?>

<?php /**PATH /Users/diseno1academy/Documents/JJ/pagebuild/vendor/larabuild/optionbuilder/src/../resources/views/components/info.blade.php ENDPATH**/ ?>