<div class="tk-skeletonwrap">
    <ul class="tk-skeleton">
        <li class="tk-skeleton_title">
            <span class="tk-skeleton_1"></span>
            <span class="tk-skeleton_2"></span>
            <span class="tk-skeleton_3"></span>
            <span class="tk-skeleton_4"></span>
            <span class="tk-skeleton_5"></span>
        </li>
        <li>
            <span class="tk-skeleton_1"></span>
            <span class="tk-skeleton_2"></span>
            <span class="tk-skeleton_3"></span>
            <span class="tk-skeleton_4"></span>
            <span class="tk-skeleton_5"></span>
        </li>
        <li>
            <span class="tk-skeleton_1"></span>
            <span class="tk-skeleton_2"></span>
            <span class="tk-skeleton_3"></span>
            <span class="tk-skeleton_4"></span>
            <span class="tk-skeleton_5"></span>
        </li>
        <li>
            <span class="tk-skeleton_1"></span>
            <span class="tk-skeleton_2"></span>
            <span class="tk-skeleton_3"></span>
            <span class="tk-skeleton_4"></span>
            <span class="tk-skeleton_5"></span>
        </li>
        <li>
            <span class="tk-skeleton_1"></span>
            <span class="tk-skeleton_2"></span>
            <span class="tk-skeleton_3"></span>
            <span class="tk-skeleton_4"></span>
            <span class="tk-skeleton_5"></span>
        </li>
        <li>
            <span class="tk-skeleton_1"></span>
            <span class="tk-skeleton_2"></span>
            <span class="tk-skeleton_3"></span>
            <span class="tk-skeleton_4"></span>
            <span class="tk-skeleton_5"></span>
        </li>
        <li>
            <span class="tk-skeleton_1"></span>
            <span class="tk-skeleton_2"></span>
            <span class="tk-skeleton_3"></span>
            <span class="tk-skeleton_4"></span>
            <span class="tk-skeleton_5"></span>
        </li>
        <li>
            <span class="tk-skeleton_1"></span>
            <span class="tk-skeleton_2"></span>
            <span class="tk-skeleton_3"></span>
            <span class="tk-skeleton_4"></span>
            <span class="tk-skeleton_5"></span>
        </li>
        <li>
            <span class="tk-skeleton_1"></span>
            <span class="tk-skeleton_2"></span>
            <span class="tk-skeleton_3"></span>
            <span class="tk-skeleton_4"></span>
            <span class="tk-skeleton_5"></span>
        </li>
        <li>
            <span class="tk-skeleton_1"></span>
            <span class="tk-skeleton_2"></span>
            <span class="tk-skeleton_3"></span>
            <span class="tk-skeleton_4"></span>
            <span class="tk-skeleton_5"></span>
        </li>
        <li>
            <span class="tk-skeleton_1"></span>
            <span class="tk-skeleton_2"></span>
            <span class="tk-skeleton_3"></span>
            <span class="tk-skeleton_4"></span>
            <span class="tk-skeleton_5"></span>
        </li>
    </ul>
</div><?php /**PATH /Users/diseno1academy/Documents/JJ/pagebuild/vendor/larabuild/pagebuilder/src/../resources/views/components/pages-skeleton.blade.php ENDPATH**/ ?>