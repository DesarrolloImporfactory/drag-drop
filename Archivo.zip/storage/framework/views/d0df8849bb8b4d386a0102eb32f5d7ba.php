<div class="tmp-about">
  <ul class="tmp-about-list">
    <li>
      <div class="tmp-sectiontitle-two">
        <span><?php echo e(pagesetting('small-heading')); ?></span>
        <h2><?php echo e(pagesetting('heading')); ?></h2>
        <p><?php echo pagesetting('paragraph'); ?></p>
      </div>
      <ul class="tmp-info-list">
        <?php if(pagesetting('bullets')): ?>
        <?php $__currentLoopData = pagesetting('bullets'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($item['bullets-point']); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
      </ul>
      <div class="tmp-join-btn">
        <a class="tmp-btn" href="<?php echo e(pagesetting('blue-cta-url')); ?>"><?php echo e(pagesetting('blue-cta')); ?>

          <i>
            <svg width="19" height="16" viewBox="0 0 19 16" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M6.6875 7.875C7.74219 7.85547 8.63086 7.49414 9.35352 6.79102C10.0566 6.06836 10.418 5.17969 10.4375 4.125C10.418 3.07031 10.0566 2.18164 9.35352 1.45898C8.63086 0.755859 7.74219 0.394531 6.6875 0.375C5.63281 0.394531 4.74414 0.755859 4.02148 1.45898C3.31836 2.18164 2.95703 3.07031 2.9375 4.125C2.95703 5.17969 3.31836 6.06836 4.02148 6.79102C4.74414 7.49414 5.63281 7.85547 6.6875 7.875ZM6.6875 1.78125C7.35156 1.80078 7.9082 2.02539 8.35742 2.45508C8.78711 2.9043 9.01172 3.46094 9.03125 4.125C9.01172 4.78906 8.78711 5.3457 8.35742 5.79492C7.9082 6.22461 7.35156 6.44922 6.6875 6.46875C6.02344 6.44922 5.4668 6.22461 5.01758 5.79492C4.58789 5.3457 4.36328 4.78906 4.34375 4.125C4.36328 3.46094 4.58789 2.9043 5.01758 2.45508C5.4668 2.02539 6.02344 1.80078 6.6875 1.78125ZM8.18164 9.28125H5.19336C3.76758 9.32031 2.57617 9.81836 1.61914 10.7754C0.662109 11.7324 0.164062 12.9238 0.125 14.3496C0.125 14.6426 0.222656 14.8867 0.417969 15.082C0.613281 15.2773 0.857422 15.375 1.15039 15.375H12.2246C12.5176 15.375 12.7617 15.2773 12.957 15.082C13.1523 14.8867 13.25 14.6426 13.25 14.3496C13.2109 12.9238 12.7129 11.7324 11.7559 10.7754C10.7988 9.81836 9.60742 9.32031 8.18164 9.28125ZM1.56055 13.9688C1.67773 13.0312 2.06836 12.25 2.73242 11.625C3.41602 11.0195 4.23633 10.707 5.19336 10.6875H8.18164C9.13867 10.707 9.94922 11.0195 10.6133 11.625C11.2969 12.25 11.6973 13.0312 11.8145 13.9688H1.56055ZM18.1719 6.23438H16.7656V4.82812C16.7266 4.39844 16.4922 4.16406 16.0625 4.125C15.6328 4.16406 15.3984 4.39844 15.3594 4.82812V6.23438H13.9531C13.5234 6.27344 13.2891 6.50781 13.25 6.9375C13.2891 7.36719 13.5234 7.60156 13.9531 7.64062H15.3594V9.04688C15.3984 9.47656 15.6328 9.71094 16.0625 9.75C16.4922 9.71094 16.7266 9.47656 16.7656 9.04688V7.64062H18.1719C18.6016 7.60156 18.8359 7.36719 18.875 6.9375C18.8359 6.50781 18.6016 6.27344 18.1719 6.23438Z"
                fill="white" />
            </svg>
          </i>
        </a>
        <a class="tmp-btnvtwo" href="<?php echo e(pagesetting('white-cta-url')); ?>"><?php echo e(pagesetting('white-cta')); ?></a>
      </div>
      <span><?php echo pagesetting('last_paragraph'); ?></span>
    </li>
    <li>
      <figure class="tmp-about-images">

        <img <?php if(!empty(pagesetting('aboutus_image'))): ?> src="<?php echo e(pagesetting('aboutus_image')[0]['thumbnail']); ?>"
          alt="<?php echo e(__('Image')); ?>" />
        <?php else: ?>
        <img src="<?php echo e(asset('demo/images/default-img.jpg')); ?>" alt="<?php echo e(__('Image')); ?>" />
        <?php endif; ?>



      </figure>
    </li>
  </ul>
</div><?php /**PATH /Users/diseno1academy/Documents/JJ/pagebuild/resources/views/pagebuilder/about-us/view.blade.php ENDPATH**/ ?>