<div class="tmp-sectionskills">
  <div class="tmp-themecontainer">
    <div class="tmp-skillssect">
      <figure>
        <?php if(!empty(pagesetting('image'))): ?>
          <img src="<?php echo e(pagesetting('image')[0]['thumbnail']); ?>" alt="<?php echo e(__('Image')); ?>" />
        <?php else: ?>
          <img src="<?php echo e(asset('demo/images/default-img.jpg')); ?>" alt="<?php echo e(__('Image')); ?>" />
        <?php endif; ?>
      </figure>
      <div class="tmp-skillwrap">
        <div class="tmp-sectiontitle">
          <ul class="tmp-colorlist">
            <li>
              <span></span>
            </li>
            <li>
              <span class="tmp-bgpink"></span>
            </li>
            <li>
              <span class="tmp-bgorange"></span>
            </li>
          </ul>
          <?php if(!empty(pagesetting('small-heading'))): ?>
            <h6><?php echo e(pagesetting('small-heading')); ?></h6>
          <?php endif; ?>
          <?php if(!empty(pagesetting('heading'))): ?>
            <h2><?php echo e(pagesetting('heading')); ?></h2>
          <?php endif; ?>
          <p>
            <?php echo pagesetting('paragraph'); ?>

          </p>
        </div>
        <div class="tmp-countes">
          <h3><?php echo e(pagesetting('counter')); ?></h3>
          <span><?php echo e(pagesetting('counter-text')); ?> </span>
          <a href="" class="tmp-btn"><?php echo e(pagesetting('button-cta')); ?> <img src="<?php echo e(asset('demo/images/iconcart.svg')); ?>"
              alt=""> </a>
        </div>
      </div>
    </div>
  </div>
</div><?php /**PATH /Users/diseno1academy/Documents/JJ/pagebuild/resources/views/pagebuilder/skills/view.blade.php ENDPATH**/ ?>