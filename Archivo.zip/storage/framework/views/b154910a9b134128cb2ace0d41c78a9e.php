<div class="tk-emptydata-holder">
    <div class="tk-emptydetails">
        <img src="<?php echo e(asset('vendor/pagebuilder/images/empty.png')); ?>">
        <em><?php echo e(__('pagebuilder::pagebuilder.no_record')); ?></em>
    </div>
</div><?php /**PATH /Users/diseno1academy/Documents/JJ/pagebuild/vendor/larabuild/pagebuilder/src/../resources/views/components/no-record.blade.php ENDPATH**/ ?>