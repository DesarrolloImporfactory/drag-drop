<div class="tmp-sectionimg">
  <figure>
    <img <?php if(!empty(pagesetting('banner_image'))): ?> src="<?php echo e(pagesetting('banner_image')[0]['thumbnail']); ?>"
      alt="<?php echo e(__('Image')); ?>" />
    <?php else: ?>
    <img src="<?php echo e(asset('demo/images/banner-placeholder.jpg')); ?>" alt="<?php echo e(__('Image')); ?>" />
    <?php endif; ?>
    <figcaption><?php echo e(pagesetting('caption')); ?></figcaption>
  </figure>
</div><?php /**PATH /Users/diseno1academy/Documents/JJ/pagebuild/resources/views/pagebuilder/banner/view.blade.php ENDPATH**/ ?>