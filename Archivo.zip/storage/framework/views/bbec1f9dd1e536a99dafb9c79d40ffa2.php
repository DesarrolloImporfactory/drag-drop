<?php $__env->startSection(config('pagebuilder.site_section')); ?>
<?php echo $pageSections; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make(config('pagebuilder.site_layout'),['page' => $page, 'edit' => false ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/diseno1academy/Documents/JJ/pagebuild/vendor/larabuild/pagebuilder/src/../resources/views/page.blade.php ENDPATH**/ ?>