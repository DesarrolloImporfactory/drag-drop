<div class="tmp-faq">
  <h2><?php echo e(pagesetting('heading')); ?></h2>
  <div class="tmp-faqsection">
    <?php if(!empty(pagesetting('faq_data'))): ?>
    <?php $__currentLoopData = pagesetting('faq_data'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="tmp-faqwrap">
      <div class="tmp-faqtitlle">
        <h6><?php echo e($faq['question']); ?></h6>
        <img src="<?php echo e(asset('demo/images/chevron-right.svg')); ?>" alt="">
      </div>
      <div class="tmp-faqcontent">
        <p><?php echo $faq['answer']; ?></p>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
  </div>
</div>

<?php if (! $__env->hasRenderedOnce('c6727f38-7877-43e9-890a-195880f301f2')): $__env->markAsRenderedOnce('c6727f38-7877-43e9-890a-195880f301f2'); ?>
  <?php $__env->startPush('page-js'); ?>
    <script>
      const accordion = document.querySelectorAll(".tmp-faqwrap");
      for(let i=0;i<accordion.length;i++){
        accordion[i].addEventListener('click',function(){
          let isActive = this.classList.contains('active');
          for(let j=0;j<accordion.length;j++){
            accordion[j].classList.remove('active');
          }
          if(isActive){
            this.classList.remove('active');
          } else{
            this.classList.add('active');
          }
        })
      };
    </script>
  <?php $__env->stopPush(); ?>
<?php endif; ?>
<?php /**PATH /Users/diseno1academy/Documents/JJ/pagebuild/resources/views/pagebuilder/faqs/view.blade.php ENDPATH**/ ?>