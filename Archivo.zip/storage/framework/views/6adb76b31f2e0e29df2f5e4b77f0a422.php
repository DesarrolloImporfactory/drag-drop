<ul class="tooltip-wrap">
    <li class="component-handle"> <a href="javascript:;"><img src="<?php echo e(asset('vendor/pagebuilder/images/toooltip1.png')); ?>" alt="img"> </a></li>
    <li class="copySection"><a href="javascript:;"> <i class="icon-copy"></i></a></li>
    <li class="deleteSection"><a href="javascript:;"><i class="icon-trash-2"></i></a></li>
</ul><?php /**PATH /Users/diseno1academy/Documents/JJ/pagebuild/vendor/larabuild/pagebuilder/src/../resources/views/components/component-actions.blade.php ENDPATH**/ ?>