<?php

return [
    'id' => 'spacer',
    'name' => __('Espaciador'),
    'icon' => '<i class="icon-credit-card"></i>',
    'tab' => "Común",
    'fields' => []
];
