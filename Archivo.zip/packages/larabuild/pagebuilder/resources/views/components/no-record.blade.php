<div class="tk-emptydata-holder">
    <div class="tk-emptydetails">
        <img src="{{ asset('vendor/pagebuilder/images/empty.png') }}">
        <em>{{ __('pagebuilder::pagebuilder.no_record') }}</em>
    </div>
</div>