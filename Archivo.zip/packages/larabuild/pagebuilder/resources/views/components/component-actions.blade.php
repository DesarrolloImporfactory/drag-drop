<ul class="tooltip-wrap">
    <li class="component-handle"> <a href="javascript:;"><img src="{{asset('vendor/pagebuilder/images/toooltip1.png')}}" alt="img"> </a></li>
    <li class="copySection"><a href="javascript:;"> <i class="icon-copy"></i></a></li>
    <li class="deleteSection"><a href="javascript:;"><i class="icon-trash-2"></i></a></li>
</ul>