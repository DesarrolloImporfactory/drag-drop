<div class="pb-emptyshortcode">
    <span>{{ 'pagebuilder::pagebuilder.no_view_found' }}</span>
</div>