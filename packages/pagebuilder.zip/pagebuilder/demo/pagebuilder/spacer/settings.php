<?php

return [
    'id' => 'spacer',
    'name' => __('Spacer'),
    'icon' => '<i class="icon-credit-card"></i>',
    'tab' => "Common",
    'fields' => []
];
