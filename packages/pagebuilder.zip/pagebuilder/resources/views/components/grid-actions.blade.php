<ul class="col-12 tooltip-wrap">
    <li class="grid-handle"><img src="{{asset('vendor/pagebuilder/images/toooltip1.png')}}" alt="img"> </li>
    <li class="insertGrid"><a href="javascript:;"> <i class="icon-plus"></i> </a> </li>
    <li class="deleteGrid"><a href="javascript:;"><i class="icon-trash-2"></i></a></li>
</ul>